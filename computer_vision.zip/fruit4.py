from tensorflow.keras.applications.resnet import ResNet50

model = ResNet50(input_shape=None,
                 classes=1000,
                 include_top=True,
                 weights='imagenet') 

from tensorflow.keras.layers import GlobalAveragePooling2D, Dense
from tensorflow.keras.models import Sequential

backbone = ResNet50(input_shape=(150, 150, 3),
                    weights='/datasets/keras_models/resnet50_weights_tf_dim_ordering_tf_kernels_notop.h5',
                    include_top=False) 

# ������������ ResNet50 ��� ��������
backbone.trainable = False

model = Sequential()
model.add(backbone)
model.add(GlobalAveragePooling2D())
model.add(Dense(12, activation='softmax')) 

model.add(Flatten())                 
model.add(Dense(units=84, activation='relu'))
model.add(Dense(units=48, activation='relu'))
model.add(Dense(units=12, activation='softmax'))
    
model.compile(optimizer=optimizer, loss='sparse_categorical_crossentropy',
                    metrics=['acc'])
