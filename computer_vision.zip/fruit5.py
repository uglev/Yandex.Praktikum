Training 1600 images belonging to 2 classes. 
 Validation 340 images belonging to 2 classes. 
 Test 340 images belonging to 2 classes. 
     
base = ResNet50(weights='../input/keras-pretrained-models/resnet50_weights_tf_dim_ordering_tf_kernels_notop.h5',
             include_top=False,
             input_shape=(150,225,3))

inp = Input(shape=(150,225,3))
base_out = base(inp)
out = Flatten()(base_out)
out = Dense(256, activation='relu')(out)
out = Dense(1, activation='sigmoid')(out)
model = Model(inp, out) 
     
def auroc(y_true, y_pred):
    auc = tf.metrics.auc(y_true, y_pred)[1]
    K.get_session().run(tf.local_variables_initializer())
    return auc

model.compile(loss='binary_crossentropy',
              optimizer=rmsprop,
              metrics=['acc',auroc]) 
     
Y_pred = model.predict_generator(test_generator,steps = 340/batch_size)
from sklearn.metrics import confusion_matrix
y_pred = Y_pred > 0.5

con_mat = tf.confusion_matrix(
    test_generator.classes,
    y_pred,
    num_classes=2,
    dtype=tf.int32,
    name=None,
    weights=None
)
with tf.Session():
   print('Confusion Matrix: nn', tf.Tensor.eval(con_mat,feed_dict=None, session=None))